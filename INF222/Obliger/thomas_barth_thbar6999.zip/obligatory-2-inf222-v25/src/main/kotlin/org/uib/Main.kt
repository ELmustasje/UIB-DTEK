package org.uib

fun main() {
    JavaTSTranspiler().run()
}
